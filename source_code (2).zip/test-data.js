// Admin oturumunu simüle et
localStorage.setItem('isAdminLoggedIn', 'true');
localStorage.setItem('adminEmail', 'gelmemeyegidenkitapkurdu@gmail.com');